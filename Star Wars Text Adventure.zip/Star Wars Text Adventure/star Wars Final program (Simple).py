import random
#import time
#from PIL import Image
#from pygame import mixer

def startGame():
    #image = Image.open('intro.jpg')
    #image.show()
    #mixer.init()
    #mixer.music.load(r'C:\Users\rmaar\OneDrive\Desktop\SJF\Python\Star Wars Pics\not come back.mp3')
    #mixer.music.play()
    #time.sleep(2)
    print("In this game, you are going to be fighting three different villains from STAR WARS. First, you will engage in combat against general grievous on utapaul while surrounded by seperatist battle droids.")
    #time.sleep(2)
    print("If you beat Grievous in the duel, your strength will be tested against Jabba's rancor on Tatooine.")
    #time.sleep(2)
    print("Finally, as an advocate for the dark side, you must take the high ground from obi wan on mustafar as Anain Skywalker.")
    #time.sleep(2)
    print("Good luck, may the force be with you")
    grievousFight()
def grievousFight():
    #image = Image.open('Greetings from obi wan.jpg')
    #image.show()
    print("Hello there")
    num1 = random.randrange(1, 21)
    if (num1 <= 4):
        print("He betrays you and you die")
        grievousFight()
    elif (num1 <= 5):
        print("He accepts peace offering, POG")
        rancorFight()
    else:
        print("You expect his betrayal and begin to duel")
        #mixer.music.load(r'C:\Users\rmaar\OneDrive\Desktop\SJF\Python\Star Wars Pics\light saber battle.mp3')
        #mixer.music.play()
        #time.sleep(5)
        #mixer.music.stop()
        print("lightsaber fight begins, you are faced with two choices. You may crush Grievous with roof or attack him with your lightsaber")
        choice = input("Would you choose to (a) crush Grievous with roof, or (b) engage in a lightsaber duel ")
        if choice == "a":
            print("He jumped out of the way, and he kills you before you have time to react")
            grievousFight()
        else:
            print("You chopped of two robot hands")
            choice = input("Would you choose to (a) final blow attempt, (b) Attack him again, or (c) Grab one of Grievous's lightsabers and dual-wield ")
            if choice == "a":
                random.randrange(1, 21)
                if (num1 <= 3):
                    print("Your final attack hit and you killed Grievous")
                    rancorFight()
                else:
                    print("Grievous overpowers you and he strikes you down and kills you")
                    grievousFight()
            elif choice == "b":
                print("You caught him off guard and you win")
                #image = Image.open('fight grievous vs obi.jpg')
                #image.show()
                rancorFight()
            else:
                print("You duel wield but Grievous overpowers you with his 3 lightsabers")
                grievousFight()
def rancorFight():
    print("You are at Jabba's palace on Tatooine")
    #image = Image.open('Jabbas palace.jpg')
    #image.show()
    #mixer.music.load(r'C:\Users\rmaar\OneDrive\Desktop\SJF\Python\Star Wars Pics\Jabba laugh.mp3')
    #mixer.music.play()
    #time.sleep(3)
    num2 = random.randrange(1, 21)
    if num2 == 1:
        print("You kil Jabba, but his guards kill you")
        rancorFight()
    else:
        print("Jabba dropped you in the pit with a rancor before you could hurt him")
        #image = Image.open('rancor and luke.jpg')
        #image.show()
        #time.sleep(2)
        print("You are in the rancor pit. You must find a way to escape.")
        choice = input("Will you choose (a) Give up (b) Get ready to fight the rancor ")
        if choice == "a":
            rancorFight()
        else:
            print("You are ready to fight, and as the rancor grabs you, you pick up a bone")
            #time.sleep(2)
            choice = input("Will you choose (a) hit the rancor (b) jam the rancor's jaw ")
            num2 = random.randrange(1, 21)
            if choice == "a":
                if num2 >= 10:
                    print("The rancor drops you")
                    rancorFight()
                else:
                    print("You are eaten")
                    rancorFight()
            else:
                print("As the rancor drops you, you are faced with a choice")
                choice = input("What will you choose (a) retreat to another corner (b) stay and fight ")
                if choice == "b":
                    print("You are overpowered, and you die")
                    rancorFight()
                else:
                    print("Because you ran away, you are able to make your next move")
                    choice = input("You have two options, will you choose (a) use a rock to smash the rancor's toe (b) throw rock for distraction ")
                    if choice == "b":
                        print("Your distraction failed, and you die")
                        rancorFight()
                    else:
                        print("The rancor screechs in pain and allows you to run to the gate")
                        choice = input("Will you choose (a) run to the button and push it (b) throw a rock at the button ")
                        if choice == "a":
                            print("The rancor catches you before you reach the button")
                            rancorFight()
                        else:
                            print("You hit the button, and the rancor is crushed by the gate; Congrats you passed")
                            #image = Image.open('dead rancor.jpg')
                            #image.show()
                            obiwanFight()
                    
            
def obiwanFight():
    #image = Image.open('mustafar base.jpg')
    #image.show()
    print("You have arried on Mustafar as Anakin Skywalker attempting to save, Queen/senator, Padme Amidala, and Obi Wan is in your way")
    #time.sleep(10)
    print("You come face to face with Obi Wan in the control room, and Obi Wan wants to attacks you")
    #image = Image.open('mustafar fight.jpg')
    #image.show()
    #mixer.music.load(r'C:\Users\rmaar\OneDrive\Desktop\SJF\Python\Star Wars Pics\chosen one.mp3')
    #mixer.music.play()
    #time.sleep(2)
    #mixer.music.load(r'C:\Users\rmaar\OneDrive\Desktop\SJF\Python\Star Wars Pics\light saber battle.mp3')
    #mixer.music.play()
    #time.sleep(5)
    #mixer.music.stop()
    choice = input("You will have to choose (a) block obi wan's attack, or (b) attack him first ")
    num3 = random.randrange(1, 21)
    if choice == "a": 
        if num3 <= 19:
            print("Obi Wan attacked and you blocked")
            choice = input("You will either choose (a) force jump to open ground, or (b) force push Obi Wan ")
            if choice == "a":
                num4 = random.randrange(1, 11)
                if num4 >= 6:
                    print("Obi Wan force pushes you into lava and you die")
                    obiwanFight()
                else:
                    print("You push obi wan into lava and you won because you had the High ground")
                    endGame()
            else:
                num5 = random.randrange(1, 11)
                if num5 == 1:
                    print("You will be sent back to the beginning")
                    grievousFight()
                else:
                    print("You force push Obi Wan into the lava")
                    endGame()
        else:
            print("He breaks through your block and you die")
            obiwanFight()
            
    else:
        num6 = random.randrange(1, 11)
        if num6 == 1:
            print("He defends and counter attack and you die")
            obiwanFight()
        else:
            print("He defends your attack but is unable to counter attack")
            choice = input("You will choose between (a) block (b) run away ")
            if choice == "a":
                print("You block Obi Wan's attack and you move on")
                choice = input("You will choose (a) attack (b) distract")
                if choice == "a":
                    print("He attacks faster than you and you die")
                    obiwanFight()
                else:
                    print("You distract Obi Wan with a mind trick and hit him with the final blow")
                    endGame()        
            else:
                print("Obi Wan catches you and you die")
                obiwanFight()
def endGame():
    print("Thanks for playing")
    #image = Image.open('ending.jpg')
    #image.show()
    #mixer.music.load(r'C:\Users\rmaar\OneDrive\Desktop\SJF\Python\Star Wars Pics\star wars theme.mp3')
    #mixer.music.play()
    
startGame()
                
            
            
            